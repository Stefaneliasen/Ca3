const URL = "http://localhost:8084/jwtbackend";
function handleHttpErrors(res) {
    if (!res.ok) {
        throw {
            message: res.statusText,
            status: res.status
        };
    }
    return res.json();
}

class ApiFacade {

    makeFetchOptions = (type, b) => {
        let headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        if (this.loggedIn()) {
            headers["x-access-token"] = this.getToken();
        }
        return {
            method: type,
            headers,
            body: JSON.stringify(b)
        }
    }

    setToken = (token) => {
        localStorage.setItem('jwtToken', token)
    }
    getToken = () => {
        return localStorage.getItem('jwtToken')
    }
    loggedIn = () => {
        const loggedIn = this.getToken() != null;
        return loggedIn;
    }
    logout = () => {
        localStorage.removeItem("jwtToken");
    }

    login = (user, pass) => {
        const options = this.makeFetchOptions("POST", {
            username: user,
            password: pass
        });
        return fetch(URL + "/api/login", options, true)
            .then(handleHttpErrors)
            .then(res => {
                this.setToken(res.token)
            })
    }
    fetchData = () => {
        const options = this.makeFetchOptions("GET");
        let whytoken = this.getToken()
        let jwtdata = whytoken.split('.')[1];
        let decodedjwtJSONdata = window.atob(jwtdata);
        let decodedJWTData = JSON.parse(decodedjwtJSONdata);
        if(decodedJWTData.roles === 'admin'){
            return fetch(URL + "/api/info/admin", options).then(handleHttpErrors);
        }
        return fetch(URL + "/api/info/user", options).then(handleHttpErrors);
        
    }
     fetchPeople = () => {
        const options = this.makeFetchOptions("GET");
        return fetch(URL + "/api/info/people/", options, true).then(handleHttpErrors);
    }
    fetchPeopleById = (id) => {
        const options = this.makeFetchOptions("GET");
        return fetch("http://localhost:8084/jwtbackend/api/info/usersearch/" + id, options, true).then(handleHttpErrors);
    }

}
const facade = new ApiFacade();
export default facade;
import React, { Component } from "react"
import facade from "./apiFacade";
import DataTable from "./DataTable";
import UserSearch from './UserSearch';
import DataTablePersons from './DataTablePersons';
import {
  HashRouter as Router,
  Route,
  NavLink,
  Switch
} from 'react-router-dom'

class LogIn extends Component {
  constructor(props) {
    super(props);
    this.state = { username: "", password: "" }
  }
  login = (evt) => {
    evt.preventDefault();
    this.props.login(this.state.username, this.state.password);
  }
  onChange = (evt) => {
    this.setState({[evt.target.id]: evt.target.value})
  }
  render() {
    return (
      <div>
        <form onSubmit={this.login} onChange={this.onChange} >
          <input placeholder="User Name" id="username" />
          <input placeholder="Password" id="password" />
          <button>Login</button>
        </form>
      </div>
    )
  }
}
class LoggedIn extends Component {
  constructor(props) {
    super(props);
    this.state= {dataFromServer: "Fetching!!"};
  }
  componentDidMount(){
    facade.fetchData().then(res=> this.setState({dataFromServer: res}));
  }
  
  render() {
    return (
<Router>
      <div>
        <Header />
      <h3>{this.state.dataFromServer}</h3>
        <Switch>
        <Route exact path="/" render={() => <Home />} />
        <Route path="/starships" render={() => <DataTable/>} />
        <Route path="/persons" render={() => <DataTablePersons/>} />
        <Route path="/usersearch" render={() => <UserSearch/>} />

        <Route component={NoMatch}/>
        </Switch>
      </div>
  </Router>
    )
  } 
}
const Header = () => (
  
  <div>
  <ul className="header">
    <li><NavLink exact activeClassName="active" to="/">Home</NavLink></li>
    <li><NavLink activeClassName="active" to="/starships">Starships</NavLink></li>
    <li><NavLink activeClassName="active" to="/persons">Persons</NavLink></li>
    <li><NavLink activeClassName="active" to="/usersearch">User Search</NavLink></li>
  </ul>
  </div>
)
const Home = () => (
  <div>
    <h2>welcome 2 home </h2>
  
  </div>
  );
  const NoMatch = ({ location }) => (
    <div>
      <h3>
        No match for <code>{location.pathname}</code>
      </h3>
    </div>
  );
class App extends Component {
  constructor(props) {
    super(props);
    this.state = { loggedIn: false
    }
  }
  logout = () => {facade.logout();
    this.setState({ loggedIn: false });}
  login = (user, pass) => {facade.login(user,pass)
    .then(res =>this.setState({ loggedIn: true }));}
  render() {
    return (
      <div>
        {!this.state.loggedIn ? (<LogIn login={this.login} />) :
          ( <div>
              <LoggedIn/>
              <button onClick={this.logout}>Logout</button>
            </div>)}
            
      </div>
    )
  }
}

export default App;


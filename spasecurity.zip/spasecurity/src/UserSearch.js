import React, { Component } from "react"
import facade from "./apiFacade";


export default class UserSearch extends Component {
    constructor(props) {
      super(props);
      this.state= {id: "", person: ""};
    }
    
  handleSubmit = async (evt) => {
    evt.preventDefault();
    const id = this.state.id;
    let fetchPeopleById = await facade.fetchPeopleById(id);
    console.log(fetchPeopleById);
    this.setState({
        person: fetchPeopleById
    
    })
    }

  handleInput = (event) => {
    this.setState({
      id : event.target.value
    });
  }
render() {
  if(this.state.person === ""){
    return (
<form onSubmit={this.handleSubmit}>
<input  name="userid" placeholder="please enter valid id" value={this.state.id} onChange={this.handleInput}/>
<br/>
<button type="submit" className="btn btn-default">look up user</button>
</form>
    )
  }
return (
  <div>
<form onSubmit={this.handleSubmit}>
<input  name="userid" placeholder="please enter valid id" value={this.state.id} onChange={this.handleInput}/>
<br/>
<button type="submit" className="btn btn-default">look up user</button>
</form>

     <ul>
         <li>
             {this.state.person.name}
         </li>
         <li>
             {this.state.person.height}
         </li>
         <li>
             {this.state.person.gender}
         </li>
     </ul>
  </div>
  )
  }
}

import React, { Component } from "react";
import DataFactory from './DataFactory';
import apiFacade from './apiFacade';
class DataTable extends React.Component {
  constructor(){
    super();
    this.state = {
      starships: [],
      people: []
    }
  }

  componentDidMount() {
    DataFactory.getStarships().then(res => this.setState({
      starships: res.results
    }))
    apiFacade.fetchPeople().then(res => this.setState({
      people: res.results
    }))
   // DataFactory.getPeople().then(res => this.setState({
    //  people: res.results
    //}))
  }
  render() {    
    console.log(this.state.people)
    const starshipRow = this.state.starships.map(starship => <tr key={starship.name}><td>{starship.model}</td></tr>)
    const peopleRow = this.state.people.map(people => <tr key={people.url}><td>{people.name}</td></tr>)
    return (
      
      <table>
        <thead>
          <tr><td>Model</td></tr>
        </thead>       
        <tbody>
          {starshipRow}  
          {peopleRow}
        </tbody>
      </table>
    
    );
  }
}
export default DataTable;
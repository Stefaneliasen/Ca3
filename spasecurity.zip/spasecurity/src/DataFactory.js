//Add imports here
import React, {
  Components
} from 'react';

function makeOptions(type, data) {
  return {
    method: type,
    body: JSON.stringify(data),
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  }
}

class DataFactory {

  getStarships() {
    return fetch("http://localhost:8084/jwtbackend/api/info/starships/").then(Response => Response.json());
  }
  getPeople() {
    return fetch("http://localhost:8084/jwtbackend/api/info/people/").then(Response => Response.json());
  }

}

export default new DataFactory();
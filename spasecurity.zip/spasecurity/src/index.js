import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';
import registerServiceWorker from './registerServiceWorker';
import DataFactory from './DataFactory';

ReactDOM.render(<App DataFactory={DataFactory}/>, document.getElementById('root'));
registerServiceWorker();
